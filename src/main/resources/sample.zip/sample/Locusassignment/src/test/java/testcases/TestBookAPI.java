package testcases;

import com.business.apiservices.BooksService;
import lombok.SneakyThrows;
import org.testng.Assert;
import org.testng.annotations.Test;
import pojos.Books.Books;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public class TestBookAPI {

    @Test(description = "Get books data - hit API endpoint https://the-one-api.dev/v2/book . It should return 3 books.")
    @SneakyThrows
    public void testBookAPI() {
        final int EXPECTED_BOOK_COUNT = 3;
        Books books = BooksService.GetBooks();
        Assert.assertEquals(books.getDocs().size(), EXPECTED_BOOK_COUNT, "Expected number of books were not returned.");
        Assert.assertEquals(books.getTotal(), EXPECTED_BOOK_COUNT, "Expected number of books were not returned in the stats.");
    }
}
