package testcases.dataproviders;

import com.business.apiservices.MoviesService;
import com.business.apiservices.auth.AuthorizationService;
import exceptions.RestClientException;
import org.testng.annotations.DataProvider;
import pojos.Movies.MovieDetailsEntry;
import pojos.Movies.Movies;

import java.io.IOException;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public class MoviesDataprovider {

    @DataProvider
    public static Object[][] generateMovieIds() {
        try {
            Movies movies = MoviesService.GetMovies(AuthorizationService.GetBearerToken());
            MovieDetailsEntry[][] movieDetailsEntries = new MovieDetailsEntry[movies.getDocs().size()][1];
            for (int i = 0; i < movies.getDocs().size(); i++) {
                movieDetailsEntries[i][0] = movies.getDocs().get(i);
            }
            return movieDetailsEntries;
        } catch (Exception e) {
            e.printStackTrace();
            return new Object[][]{{}};
        }
    }
}
