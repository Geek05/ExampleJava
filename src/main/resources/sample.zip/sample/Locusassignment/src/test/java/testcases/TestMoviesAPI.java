package testcases;

import com.business.apiservices.MoviesService;
import com.business.apiservices.auth.AuthorizationService;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.util.Strings;
import org.testng.Assert;
import org.testng.annotations.Test;
import pojos.Movies.MovieDetailsEntry;
import pojos.Movies.MovieQuotes;
import pojos.Movies.Movies;
import testcases.dataproviders.MoviesDataprovider;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Log4j2
public class TestMoviesAPI {

    @Test(description = "Negative case for getting movies - hit API endpoint https://the-one-api.dev/v2/movie. Check for the negative case.")
    @SneakyThrows
    public void testMoviesAPIWithoutAuth() {
        String emptyBearerToken = null;
        Movies movies = MoviesService.GetMovies(emptyBearerToken);
        Assert.assertEquals(movies.isSuccess(), false, "Api responded with data without Authorization.");
        Assert.assertEquals(movies.getMessage(), "Unauthorized.", "Api responded with data without Authorization.");
    }

    @Test(description = "Positive case for getting movies - hit same endpoint as above but with Bearer token 4qAaXynbVomwqHwO6MXW . Assert on the correct response. ")
    @SneakyThrows
    public void testMoviesAPIWithAuth() {
        Movies movies = MoviesService.GetMovies(AuthorizationService.GetBearerToken());
        Assert.assertNotNull(movies.getTotal());
        if (movies.getTotal() > 0) {
            Assert.assertNotNull(movies.getOffset());
            Assert.assertTrue(movies.getPage() >= 1, "Page count cannot be less than or equal to 0.");
            Assert.assertTrue(movies.getPages() >= 1, "Pages count cannot be less than or equal to 0.");
            Assert.assertTrue(movies.getLimit() >= 1, "Default limit cannot be less than or equal to 0.");

            //pagination is ignored intentionally for now, due to time constraint and assignment limitations
            Assert.assertTrue(movies.getTotal() == movies.getDocs().size() || movies.getLimit() == movies.getDocs().size(),
                    "Stats Total number is not same as documents/movies count.");
        } else {
            //Not sure of 0 records api response, so keeping it as empty to add it later.
            //0 response, this has to be validated against underlying database
        }
    }


    @Test(description = "Two step case - get the list of movies from the above case & now you need to get the quote of a movie from the url https://the-one-api.dev/v2/movie/{id}/quote where id is the id of the one the movies returned from the above url. Assert for the usecase working fine.",
            dataProvider = "generateMovieIds", dataProviderClass = MoviesDataprovider.class)
    @SneakyThrows
    public void testMovieQuotes(MovieDetailsEntry movieDetailsEntry) {

        MovieQuotes movieQuotes = MoviesService.GetMovieQuotes(AuthorizationService.GetBearerToken(), movieDetailsEntry.get_id());

        Assert.assertTrue(movieQuotes.getTotal() > 0,
                String.format("No Quotes found for movie id %s [%s]", movieDetailsEntry.get_id(), movieDetailsEntry.getName()));


        //pagination is ignored intentionally for now, due to time constraint and assignment limitations
        Assert.assertTrue((movieQuotes.getTotal() == movieQuotes.getDocs().size() || movieQuotes.limit == movieQuotes.getDocs().size()),
                String.format("Stats count and number of quotes returned are not matching for movie id %s", movieDetailsEntry.get_id()));

        movieQuotes.getDocs()
                .parallelStream()
                .forEach(movieQuote -> {
                    Assert.assertTrue(Strings.isNotEmpty(movieQuote.get_id()), String.format("Field 'id' is empty/null for movie id %s", movieDetailsEntry.get_id()));
                    Assert.assertTrue(Strings.isNotEmpty(movieQuote.getMovie()), String.format("Field 'movie' is empty/null for movie id %s", movieDetailsEntry.get_id()));
                    Assert.assertTrue(Strings.isNotEmpty(movieQuote.getCharacter()), String.format("Field 'character' is empty/null for movie id %s", movieDetailsEntry.get_id()));
                    Assert.assertTrue(Strings.isNotEmpty(movieQuote.getDialog()), String.format("Field 'dialog' is empty/null for movie id [%s] and quoteid [%s]", movieDetailsEntry.get_id(), movieQuote.get_id()));
                    Assert.assertTrue(movieQuote.getDialog().trim().split("\\W").length > 0, String.format("Field 'dialog' has no words for movie id [%s] and quoteid [%s]", movieDetailsEntry.get_id(), movieQuote.get_id()));
                });
    }

    /**
     * Enhancements:
     * Move to errorcode mappging of all errors.
     * Custom reporting
     */

    /**
     * Test output reports are generated under /test-output directory
     */

}
