package pojos.Movies;

import lombok.Data;
import pojos.common.AbstractResponse;

import java.util.List;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class MovieQuotes extends AbstractResponse {
    public List<MovieQuoteEntry> docs;
}
