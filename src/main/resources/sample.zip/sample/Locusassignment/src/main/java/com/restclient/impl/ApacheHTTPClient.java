package com.restclient.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.restclient.HTTPMethod;
import com.restclient.HTTPProtocol;
import com.restclient.RestClient;
import exceptions.RestClientException;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ConnectionPoolTimeoutException;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.util.Strings;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Log4j2
@NoArgsConstructor
public class ApacheHTTPClient implements RestClient {

    private String host;
    private String resourcePath;
    private String URI;
    private HTTPMethod httpRequestMethod;
    HTTPProtocol httpProtocol;
    private HttpResponse response;
    private String responseBody;
    private int responseStatus;
    private Map<String, String> responseCookies = new HashMap<>();
    private Map<String, String> requestHeader = new HashMap<>();
    private Map<String, String> responseHeaders = new HashMap<>();

    @Override
    public RestClient addHeaders(Map<String, String> headers) {
        this.requestHeader = headers;
        return this;
    }

    @Override
    public RestClient setProtocol(HTTPProtocol httpProtocol) {
        this.httpProtocol = httpProtocol;
        return this;
    }

    @Override
    public RestClient setHost(String host) {
        this.host = host;
        return this;
    }

    @Override
    public RestClient setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
        return this;
    }

    @Override
    public RestClient setRequestType(HTTPMethod httpMethod) {
        this.httpRequestMethod = httpMethod;
        return this;
    }

    @Override
    public int getResponseStatus() {
        return responseStatus;
    }

    @Override
    public Map<String, String> getResponseHeaders() {
        return responseHeaders;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    @Override
    public RestClient post(String payload) throws UnsupportedEncodingException {
        return null;
    }

    @Override
    public RestClient get() throws RestClientException {

        this.httpRequestMethod = HTTPMethod.GET;
        HttpGet getRequest = new HttpGet(getURI());

        if (Objects.nonNull(requestHeader) && !requestHeader.isEmpty()) {
            for (String key : requestHeader.keySet()) {
                getRequest.addHeader(key, requestHeader.get(key));
            }
        }
        try (CloseableHttpClient httpclient = getHTTPClient()) {
            response = httpclient.execute(getRequest);
            log.info("GET response received {} ", response);

            responseStatus = response.getStatusLine().getStatusCode();
            log.info("GET response status {} ", String.valueOf(responseStatus));
            HttpEntity resEntity = response.getEntity();
            byte[] responseBodyStream;
            try (InputStream inStream = resEntity.getContent();) {
                responseBodyStream = IOUtils.toByteArray(inStream);
                responseBody = new String(responseBodyStream);
                printResponse(responseBody);
            }

            setResponseHeaders(response.getAllHeaders());

            if ((resEntity != null)) {
                //safe condition
                EntityUtils.consume(resEntity);
            }

        } catch (IOException e) {
            throw new RuntimeException("Error calling get request " + e.getMessage(), e);
        }

        return this;
    }

    private void printResponse(String responseBody) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        log.info(gson.toJson(JsonParser.parseString(responseBody)));
    }

    private void setResponseHeaders(Header[] allHeaders) {
        for (Header header : allHeaders) {
            responseHeaders.put(header.getName(), header.getValue());
        }
    }

    public CloseableHttpClient getHTTPClient() {
        SSLContextBuilder sshbuilder = new SSLContextBuilder();
        try {
            sshbuilder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sshbuilder.build(), NoopHostnameVerifier.INSTANCE);
            HttpClientBuilder clientBuilder = HttpClients.custom().setSSLSocketFactory(sslsf);
            clientBuilder.setRetryHandler(new HttpRequestRetryHandler() {
                int executionCount = 1;

                public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
                    if ((exception instanceof ConnectTimeoutException || exception instanceof ConnectionPoolTimeoutException) && executionCount <= 3) {
                        ++this.executionCount;
                        return true;
                    } else {
                        return false;
                    }
                }
            });
            return clientBuilder.build();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getURI() throws RestClientException {
        if (Objects.isNull(httpProtocol.value()) || Strings.isEmpty(host) || Strings.isEmpty(resourcePath)) {
            throw new RestClientException("Http protocol or Host or resource path is null. Please check URI");
        }
        this.URI = String.format("%s%s/%s", httpProtocol.value(), host, resourcePath);
        return URI;
    }
}
