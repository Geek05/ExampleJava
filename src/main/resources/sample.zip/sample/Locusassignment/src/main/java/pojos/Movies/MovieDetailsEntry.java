package pojos.Movies;

import lombok.Data;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class MovieDetailsEntry {
    public String _id;
    public String name;
    public int runtimeInMinutes;
    public int budgetInMillions;
    public double boxOfficeRevenueInMillions;
    public int academyAwardNominations;
    public int academyAwardWins;
    public double rottenTomatesScore;
}
