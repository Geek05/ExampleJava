package com.restclient;

import lombok.experimental.UtilityClass;
import org.apache.logging.log4j.util.Strings;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@UtilityClass
public class CommonHeaders {

    public Map<String, String> GetJsonHeader() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept", "application/json");
        return headers;
    }

    public Map<String, String> GetJsonHeaderWithAuthtoken(String token) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept", "application/json");
        if(!Strings.isEmpty(token))
            headers.put("Authorization", "Bearer " + token);
        return headers;
    }

}
