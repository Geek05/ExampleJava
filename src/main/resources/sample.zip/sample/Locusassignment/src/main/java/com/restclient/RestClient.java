package com.restclient;

import exceptions.RestClientException;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public interface RestClient {

    String REST_CLIENT_PROPERTIES_FILE = "restclient.properties";

    RestClient addHeaders(Map<String, String> headers);

    RestClient setProtocol(HTTPProtocol httpProtocol);

    RestClient setHost(String host);

    RestClient setResourcePath(String path);

    RestClient setRequestType(HTTPMethod httpMethod);

    int getResponseStatus();

    Map<String, String> getResponseHeaders();

    String getResponseBody();

    RestClient post(String payload) throws UnsupportedEncodingException;

    RestClient get() throws RestClientException;
}
