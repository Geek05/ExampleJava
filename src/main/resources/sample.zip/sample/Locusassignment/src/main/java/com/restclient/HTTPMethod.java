package com.restclient;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public enum HTTPMethod {
    GET,
    POST
}
