package com.business.commons;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public interface Services {

    //Can/has to be read from properties file

    String THE_ONE_API_DEV = "the-one-api.dev";
}
