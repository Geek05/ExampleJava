package pojos.Movies;

import lombok.Data;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class MovieQuoteEntry {
    public String _id;
    public String dialog;
    public String movie;
    public String character;
}
