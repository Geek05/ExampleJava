package com.business.apiservices;

import com.business.commons.APIResources;
import com.business.commons.Services;
import com.restclient.CommonHeaders;
import com.restclient.HTTPProtocol;
import com.restclient.ObjectMappers;
import com.restclient.RestClient;
import com.restclient.impl.ApacheHTTPClient;
import exceptions.RestClientException;
import lombok.experimental.UtilityClass;
import pojos.Books.Books;
import pojos.Movies.MovieQuotes;
import pojos.Movies.Movies;

import java.io.IOException;
import java.text.MessageFormat;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@UtilityClass
public class MoviesService implements Services {

    /**
     * Filtering/pagination not considered intentionally due to time and assignment limitations
     */

    public Movies GetMovies(String authToken) throws RestClientException, IOException {
        RestClient restClient = new ApacheHTTPClient();
        String response = restClient.setProtocol(HTTPProtocol.HTTPS)
                .setHost(THE_ONE_API_DEV)
                .setResourcePath(APIResources.MOVIES)
                .addHeaders(CommonHeaders.GetJsonHeaderWithAuthtoken(authToken))
                .get()
                .getResponseBody();
        return (Movies) ObjectMappers.JsonToObject(response, new Movies());
    }

    public MovieQuotes GetMovieQuotes(String authToken, String movieId) throws RestClientException, IOException {
        RestClient restClient = new ApacheHTTPClient();
        String response = restClient.setProtocol(HTTPProtocol.HTTPS)
                .setHost(THE_ONE_API_DEV)
                .setResourcePath(MessageFormat.format(APIResources.MOVIE_QUOTES, movieId))
                .addHeaders(CommonHeaders.GetJsonHeaderWithAuthtoken(authToken))
                .get()
                .getResponseBody();
        return (MovieQuotes) ObjectMappers.JsonToObject(response, new MovieQuotes());
    }

}
