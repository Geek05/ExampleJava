package pojos.Movies;

import lombok.Data;
import pojos.common.AbstractResponse;

import java.util.List;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class Movies extends AbstractResponse {
    public List<MovieDetailsEntry> docs;
}
