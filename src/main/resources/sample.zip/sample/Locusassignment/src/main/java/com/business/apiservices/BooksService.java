package com.business.apiservices;

import com.business.commons.APIResources;
import com.business.commons.Services;
import com.restclient.CommonHeaders;
import com.restclient.HTTPProtocol;
import com.restclient.ObjectMappers;
import com.restclient.RestClient;
import com.restclient.impl.ApacheHTTPClient;
import exceptions.RestClientException;
import lombok.experimental.UtilityClass;
import pojos.Books.Books;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@UtilityClass
public class BooksService implements Services {

    public Books GetBooks() throws RestClientException, IOException {
        RestClient restClient = new ApacheHTTPClient();
        String response = restClient.setProtocol(HTTPProtocol.HTTPS)
                .setHost(THE_ONE_API_DEV)
                .setResourcePath(APIResources.BOOKS)
                .addHeaders(CommonHeaders.GetJsonHeader())
                .get()
                .getResponseBody();
        return (Books) ObjectMappers.JsonToObject(response, new Books());
    }

}
