package com.business.commons;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public class APIResources {

    public static final String BOOKS = "v2/book";

    public static final String MOVIES = "v2/movie";

    public static final String MOVIE_QUOTES = "v2/movie/{0}/quote";
}
