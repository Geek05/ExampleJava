package com.restclient;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public enum HTTPProtocol {
    HTTP("http://"),
    HTTPS("https://");

    String protocolString;
    HTTPProtocol(String protocolString) {
        this.protocolString = protocolString;
    }

    public String value(){
        return this.protocolString;
    }
}
