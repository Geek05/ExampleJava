package pojos.Books;

import lombok.Data;
import pojos.common.AbstractResponse;

import java.util.List;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class Books extends AbstractResponse {
    List<Document> docs;
}
