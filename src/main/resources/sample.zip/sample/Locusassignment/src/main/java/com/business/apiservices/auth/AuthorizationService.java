package com.business.apiservices.auth;

import lombok.experimental.UtilityClass;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@UtilityClass
public class AuthorizationService {

    public String GetBearerToken() {
        //some logic
        return "4qAaXynbVomwqHwO6MXW";
    }
}
