package pojos.Books;

import lombok.Data;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class Document {
    public String _id;
    public String name;
}
