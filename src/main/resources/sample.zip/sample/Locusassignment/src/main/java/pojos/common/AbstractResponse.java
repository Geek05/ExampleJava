package pojos.common;

import lombok.Data;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
@Data
public class AbstractResponse {

    public int total;
    public int limit;
    public int offset;
    public int page;
    public int pages;

    public boolean success;
    public String message;
}
