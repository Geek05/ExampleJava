package exceptions;

/**
 * @author Bharath.MC
 * @since Feb-2021
 */
public class RestClientException extends Exception{

    public RestClientException(String message){
        super(message);
    }
}
