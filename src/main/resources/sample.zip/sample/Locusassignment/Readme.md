**Execution Steps**

To execute the testcases run the TestNG file which is located under below directory.

**TestNG File**: <code> src/test/resources/TestNG/TestAPIs.xml </code>


Test **report** can be found under: <code> /test-output </code> Directory.


<code>
Thanks,
</code>
<br>
<code>
Bharath
</code>